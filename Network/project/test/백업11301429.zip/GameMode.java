public class GameMode 
{
	static final int BEFORE = 0;
	static final int NOTMYTURN = 1;
	static final int MYTURN = 2;
	
	public static int gameMode = BEFORE;
}
